description: AddFastWordpieceDetokenize(arg0: int) -> None

<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="text.tflite_registrar.AddFastWordpieceDetokenize" />
<meta itemprop="path" content="Stable" />
</div>

# text.tflite_registrar.AddFastWordpieceDetokenize

<!-- Insert buttons and diff -->

<table class="tfo-notebook-buttons tfo-api nocontent" align="left">

</table>

AddFastWordpieceDetokenize(arg0: int) -> None

<pre class="devsite-click-to-copy prettyprint lang-py tfo-signature-link">
<code>text.tflite_registrar.AddFastWordpieceDetokenize()
</code></pre>

<!-- Placeholder for "Used in" -->

The function that adds FastWordpieceDetokenize to the TFLite interpreter.
