description: AddFastSentencepieceDetokenize(arg0: int) -> None

<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="text.tflite_registrar.AddFastSentencepieceDetokenize" />
<meta itemprop="path" content="Stable" />
</div>

# text.tflite_registrar.AddFastSentencepieceDetokenize

<!-- Insert buttons and diff -->

<table class="tfo-notebook-buttons tfo-api nocontent" align="left">

</table>

AddFastSentencepieceDetokenize(arg0: int) -> None

<pre class="devsite-click-to-copy prettyprint lang-py tfo-signature-link">
<code>text.tflite_registrar.AddFastSentencepieceDetokenize()
</code></pre>

<!-- Placeholder for "Used in" -->

Adds AddFastSentencepieceDetokenize to the TFLite interpreter.
