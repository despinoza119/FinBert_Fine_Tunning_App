description: AddFastBertNormalize(arg0: int) -> None

<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="text.tflite_registrar.AddFastBertNormalize" />
<meta itemprop="path" content="Stable" />
</div>

# text.tflite_registrar.AddFastBertNormalize

<!-- Insert buttons and diff -->

<table class="tfo-notebook-buttons tfo-api nocontent" align="left">

</table>

AddFastBertNormalize(arg0: int) -> None

<pre class="devsite-click-to-copy prettyprint lang-py tfo-signature-link">
<code>text.tflite_registrar.AddFastBertNormalize()
</code></pre>

<!-- Placeholder for "Used in" -->

The function that adds FastBertNormalize to the TFLite interpreter.
