description: build_fast_bert_normalizer_model(arg0: bool) -> bytes

<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="text.build_fast_bert_normalizer_model" />
<meta itemprop="path" content="Stable" />
</div>

# text.build_fast_bert_normalizer_model

<!-- Insert buttons and diff -->

<table class="tfo-notebook-buttons tfo-api nocontent" align="left">

</table>

build_fast_bert_normalizer_model(arg0: bool) -> bytes

<pre class="devsite-click-to-copy prettyprint lang-py tfo-signature-link">
<code>text.build_fast_bert_normalizer_model()
</code></pre>

<!-- Placeholder for "Used in" -->
