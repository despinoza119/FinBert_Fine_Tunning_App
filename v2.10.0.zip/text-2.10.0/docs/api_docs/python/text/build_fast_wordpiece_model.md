description: build_fast_wordpiece_model(arg0: List[str], arg1: int, arg2: str,
arg3: str, arg4: bool, arg5: bool) -> bytes

<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="text.build_fast_wordpiece_model" />
<meta itemprop="path" content="Stable" />
</div>

# text.build_fast_wordpiece_model

<!-- Insert buttons and diff -->

<table class="tfo-notebook-buttons tfo-api nocontent" align="left">

</table>

build_fast_wordpiece_model(arg0: List[str], arg1: int, arg2: str, arg3: str,
arg4: bool, arg5: bool) -> bytes

<pre class="devsite-click-to-copy prettyprint lang-py tfo-signature-link">
<code>text.build_fast_wordpiece_model()
</code></pre>

<!-- Placeholder for "Used in" -->
